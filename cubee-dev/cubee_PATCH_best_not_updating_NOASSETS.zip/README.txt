このパッチは assets/ を一切変更しません（アイコン等は触りません）。
修正内容:
- BESTスコア保存キーを固定（cubee_best_first / cubee_best_normal / cubee_best_time）
- endGame() でも BEST を確実に更新・保存（B/N/TT共通）

適用方法:
- cubee-dev/main.js を上書き（dev用）
- 必要なら cubee/main.js も上書き（本番用）
